package com.example.districts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistrictsApplicationTests {

	@Test
	void contextLoads() {
	}

}
