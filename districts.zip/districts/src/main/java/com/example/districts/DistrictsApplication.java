package com.example.districts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistrictsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DistrictsApplication.class, args);
	}

}
